package com.interland.springprojectlibrary.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.interland.springprojectlibrary.dto.BookDTO;
import com.interland.springprojectlibrary.entity.Book;



@Service
public interface BookService {

	public List<Book> getAll();
	BookDTO GetBookById(Long bookId);
	public List<Book> saveBook(List<Book> book) ;
}
