package com.interland.springprojectlibrary.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.interland.springprojectlibrary.dto.BookDTO;
import com.interland.springprojectlibrary.entity.Book;
import com.interland.springprojectlibrary.service.BookService;



@RestController
@RequestMapping("/library")
public class LibraryController {
	
	
@Autowired
BookService service;
	
	
	
	
	@GetMapping("/findAll")   
	public  List<Book> findAll(){
		
		return service.getAll();
	}
	
	@GetMapping("/book/{id}")
	public BookDTO GetBookId(@PathVariable Long id) {
		
		return service.GetBookById(id); 
		
	}
	
	@GetMapping("/bookid")
	public BookDTO GetBookIdNew(@RequestParam("id") Long id) {
		
		return service.GetBookById(id); 
		
	}
	
	@PostMapping("/addbook")
	public List<Book> saveBook(@Validated  @RequestBody List<Book> book){
		return service.saveBook(book);
	}
	
}
