package com.interland.springprojectlibrary.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.interland.springprojectlibrary.repository.BookRepository;
import com.interland.springprojectlibrary.dto.BookDTO;
import com.interland.springprojectlibrary.entity.Book;


@Service
public class BookServiceImp implements BookService {
	
	@Autowired
	BookRepository bookRepository;

	public List<Book> getAll() {
		return bookRepository.findAll();
	
	}

	
	
	public BookDTO GetBookById(Long bookId) {
		Book book=new Book();
		BookDTO  bookDto=new BookDTO();
		try {
			book=bookRepository.getById(bookId);
			if(book!=null)
			{	
				
				bookDto.setBookId(book.getBookId());
				bookDto.setBookName(book.getBookName());
				bookDto.setAuthorName(book.getAuthorName());
				bookDto.setBookPrice(book.getBookPrice());
				
				
			}
			return bookDto;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			return null;
		}

	}
	
	public List<Book> saveBook(List<Book> book){
		return bookRepository.saveAll(book);
	}
}

	
	
 
