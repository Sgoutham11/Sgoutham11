package com.interland.springprojectlibrary;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectLibraryApplicationTests {

	@Test
	void contextLoads() {
	}

}
